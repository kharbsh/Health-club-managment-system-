# Health-club-managment-system-

This system can install in any Health Club or Gym. 

This system contains the following modules:

  1.Administrative Module
      a)Admin has username and password and can alter them.
      b)Admin manages coaches and members(Add, Delete, update, List,search).
      c)Admin manages Billing. d)Admin can make reports about members.
      e)Admin assign members to their coaches.
      f)System Must send notification when subscription of member end.
      
  2.Coach Module
      a)Coach can put plan and timeline schedule for his members.
      b)Coach can send message for his All members. 
      
  3.Member Module
      a)Member can see end date of subscription. 
      b)Member can see his Coach and his Schedule.
      c)System Must send notification when subscription of member end.
      
  4.User Module
      a)All Users can login and logout.
      b)Users can Update their Information except ID.
